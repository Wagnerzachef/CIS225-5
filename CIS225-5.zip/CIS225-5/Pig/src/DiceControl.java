import java.util.ArrayList;
/**
 * Class to control dice.
 *
 * @author Zach Wagner
 * @version 1
 */
public class DiceControl
{
    // instance variables - replace the example below with your own
    private ArrayList<Die> dice;

    /**
     * Constructor for objects of class DiceControl
     */
    public DiceControl()
    {
        // initialise instance variables
        dice = new ArrayList<>();
        addDice();
    }

    /**
     * A method to roll dice an save the integer value
     *
     * @return    the rolls a player has made in total
     */
    public ArrayList<Integer> rollTheDice()
    {
        // put your code here
        ArrayList<Integer> rolls = new ArrayList<Integer>();
        for(Die die : dice) {
            rolls.add(die.rollDie());
        }
        return rolls;
    }
    /**
     * method to check for ones in the rolled dice
     *
     * @param
     * @return    a true if there is a one, and a false if there isn't
     */
    public boolean checkForOne(ArrayList<Integer> rolls)
    {
        for(Integer roll : rolls) {
            if(roll == 1) {
                return true;
            }
        }
        return false;
    }
    /**
     * method to print out the current rolled values
     *
     * @param
     */
    public void printTheRolls(ArrayList<Integer> rolls)
    {
        System.out.println("Current Rolls: ");
        for(Integer roll : rolls) {
            System.out.print(" " + roll);
            System.out.println();
        }
    }
    /**
     * method to add dice to the dice array list
     */
    private void addDice()
    {
        for(int i = 0; i < 2; i++) {
            dice.add(new Die());
        }
    }
}
