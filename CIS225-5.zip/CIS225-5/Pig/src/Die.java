import java.util.Random;
/**
 * Class to make a single die object.
 *
 * @author Zach Wagner
 * @version 1
 */
public class Die
{

    /**
     * Method to roll a singular die and return the outcome
     *
     * @return    the random die's number
     */
    public int rollDie()
    {
        // put your code here
        Random rDie = new Random();
        return rDie.nextInt(6) + 1;
    }
}
