import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
/**
 * The class that will play the game.
 *
 * @author Zach Wagner
 * @version 1
 */
public class Pig
{
    // instance variables - replace the example below with your own
    private String player1;
    private String player2;
    private int player1Score;
    private int player2Score;
    private int currentPlayer;
    private int winner;
    private DiceControl dice;

    /**
     * Constructor for objects of class Pig
     */
    public Pig()
    {
        // initialise instance variables
        dice = new DiceControl();
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param
     * @return    the sum of x and y
     */
    public void game()
    {
        // put your code here
        boolean gameOver = false;
        SaveWinners winners = new SaveWinners();
        while(!gameOver) {
            boolean roundOver = false;
            player1Score = 0;
            player2Score = 0;
            currentPlayer = 0;
            winner = 0;
            System.out.println("Welcome to the 2 dice game Pig");
            winners.printWinners();
            setPlayers();
            while(!roundOver) {
                setCurrentPlayer();
                rollPlayer();
                printScores();
                checkForWinner();
                if(winner != 0) {
                    printWinner();
                    saveWinner();
                    roundOver = true;
                    System.out.println("The game has been completed. Goodbye.");
                    gameOver = true;
                }
            }
        }
    }
    /**
     * method that controls the players inputs and simulates a single round of Pig
     */
    private void rollPlayer()
    {
        int total = 0;
        boolean finish = false;
        Scanner scan = new Scanner(System.in);
        if(currentPlayer == 1) {
            System.out.println("It is " + player1 + "'s turn.");
        }
        else {
            System.out.println("It is " + player2 + "'s turn.");
        }
        System.out.println("Enter '1' to roll. Enter '2' to stop.");
        do {
            String input = scan.next();
            if(input.equals("1")) {
                ArrayList<Integer> rolls = new ArrayList<Integer>(dice.rollTheDice());
                dice.printTheRolls(rolls);
                if(dice.checkForOne(rolls)) {
                    total = 0;
                    System.out.println("You rolled a one. Score reset for this round.");
                    finish = true;
                }
                else {
                    for(Integer roll : rolls) {
                        total += roll;
                    }
                }
            }
            else {
                if(currentPlayer == 1) {
                    add1Score(total);
                }
                else {
                    add2Score(total);
                }
                finish = true;
            }
        }
        while(!finish);
    }
    /**
     * method to set the player names
     */
    private void setPlayers()
    {
        Scanner scan = new Scanner(System.in);
        System.out.println("What is the first players name?");
        player1 = scan.next();
        System.out.println("What is the second players name?");
        player2 = scan.next();
    }
    /**
     * method to set the current player
     */
    private void setCurrentPlayer()
    {
        if(currentPlayer == 0) {
            Random rand = new Random();
            currentPlayer = rand.nextInt(2) + 1;
        }
        else {
            if(currentPlayer == 1) {
                currentPlayer = 2;
            }
            else {
                currentPlayer = 1;
            }
        }
    }
    /**
     * method to check for winners
     */
    private void checkForWinner()
    {
        if(currentPlayer == 1) {
            if(player1Score >= 100) {
                winner = 1;
            }
        }
        else {
            if(player2Score >= 100) {
                winner = 2;
            }
        }
    }
    /**
     * method to print the scores of the players
     */
    private void printScores()
    {
        System.out.println(player1 + " score: " + player1Score);
        System.out.println(player2 + " score: " + player2Score);
    }
    /**
     * method to print the winning player
     */
    private void printWinner()
    {
        if(winner == 1) {
            System.out.println(player1 + " won");
        }
        else if(winner == 2) {
            System.out.println(player2 + " won");
        }
    }
    /**
     * method to save new winners to the winnersFile
     */
    private void saveWinner()
    {
        SaveWinners winners = new SaveWinners();
        if(winner == 1) {
            winners.appendWinnersFile(player1);
        }
        else if(winner == 2) {
            winners.appendWinnersFile(player2);
        }

    }
    /**
     * method to add the new score to the players score
     */
    private void add1Score(int score)
    {
        player1Score += score;
    }
    /**
     * method to add the new score to the players score
     */
    private void add2Score(int score)
    {
        player2Score += score;
    }
}
