import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

/**
 * Class to take the winneres of the dice game and save them to a file.
 *
 * @author Zach Wagner
 * @version 1
 */
public class SaveWinners
{
    // instance variables - replace the example below with your own
    ArrayList<String> winners;
    File winnerFile;

    /**
     * Constructor for objects of class SaveWinners
     */
    public SaveWinners()
    {
        // initialise instance variables
        winners = new ArrayList<String>(Arrays.asList("","","","",""));
        winnerFile = new File("winnerFile.csv");
        checkWinners();
    }

    /**
     * A method to get the previous winners of the game.
     *
     */
    public void printWinners()
    {
        // put your code here
        checkWinners();
        if(!winners.isEmpty()) {
            System.out.println("The previous winners are: ");
            for(String winner : winners) {
                System.out.print(winner);
            }
        }
        else {
            System.out.println("There are no previous winners currently.");
        }
    }
    /**
     * method to add new winners to the winnersFile
     */
    public void appendWinnersFile(String winner)
    {
        try {
            FileWriter writer = new FileWriter(winnerFile.getAbsoluteFile(), true);
            BufferedWriter buff = new BufferedWriter(writer);
            buff.write("," + winner);
            buff.flush();
            buff.close();
        }
        catch(IOException e) {
            System.out.println("Error saving winner to " + winnerFile);
        }
    }
    /**
     * a method to check and add the winners in the winnerFile 
     * and add them to the winner list
     */
    private void checkWinners()
    {
        try {
            int counter = 0;
            Scanner scan = new Scanner(winnerFile);
            String[] winnersList = scan.nextLine().split(",");
            for(int i = winnersList.length - 1; i > winnersList.length - 6; i--) {
                if(i >= 0) {
                    winners.set(counter, winnersList[i]);
                    counter++;
                }
                else {
                    break;
                }
            }
        }
        catch(FileNotFoundException e) {
            System.out.println("Error loading " + winnerFile);
        }
    }
}