import java.util.List;
import java.util.Random;

/**
 * Write a description of class Animal here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public abstract class Animal implements Actor
{
    // instance variables - replace the example below with your own
    
    protected boolean alive;
    protected static final Random rand = Randomizer.getRandom();
    protected Location location;
    protected int age;
    protected Field field;

    /**
     * Constructor for objects of class Animal
     */
    public Animal(Field field, Location location)
    {
        // initialise instance variables
        age = 0;
        alive = true;
        this.field = field;
        setLocation(location);
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    protected Field getField()
    {
        // put your code here
        return field;
    }
    protected void setAge(int age)
    {
        this.age = age;
    }
    protected int getAge()
    {
        return age;
    }
    public Location getLocation()
    {
        return location;
    }
    protected boolean isAlive()
    {
        return alive;
    }
    protected void setLocation(Location newLocation)
    {
        if(location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    protected void setDead()
    {
        alive = false;
        if(location != null) {
            field.clear(location);
            location = null;
            field = null;
        }
    }
    protected boolean canBreed()
    {
        return age >= getBreedingAge();
    }
    protected void incrementAge()
    {
        age++;
        if(age > getMaxAge()) {
            setDead();
        }
    }
    protected int breed() 
    { 
        int births = 0;
        if(canBreed() && rand.nextDouble() <= getBreedingProbability()) {
            births = rand.nextInt(getMaxLitterSize()) + 1;
        } 
        return births;
    }
    protected void giveBirth(List<Animal> newAnimals)
    { 
        Field field = getField();
        List<Location> free = field.getFreeAdjacentLocations(getLocation());
        int births = breed(); 
        for (int b = 0; b < births && free.size() > 0; b++) { 
            Location loc = free.remove(0); 
            Animal young = createAnimal(false, field, loc); 
            newAnimals.add(young); 
        } 
    }
    abstract protected int getBreedingAge();
    abstract protected int getMaxAge();
    abstract protected double getBreedingProbability();
    abstract protected int getMaxLitterSize();
    abstract protected Animal createAnimal(boolean randomAge, Field field, Location loc);
}
