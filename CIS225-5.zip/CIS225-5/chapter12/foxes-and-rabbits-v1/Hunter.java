import java.util.Random;
import java.util.List;
import java.util.Iterator;

/**
 * Write a description of class Hunter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Hunter implements Actor
{
    // instance variables - replace the example below with your own
    private final Field field;
    private Location location;
    private static final Random random = new Random();
    private static final int NUMBER_OF_SHOTS = 4;
    private boolean alive;

    /**
     * Constructor for objects of class Hunter
     */
    public Hunter(boolean alive, Field field, Location location) 
    {
        this.field = field;
        setLocation(location);
        this.alive = alive;
    }
    public boolean isActive()
    { 
        return alive;
    }
    public void act(List newActors) 
    { 
        Location newLocation = getRandomLocation();
        Object obj = field.getObjectAt(newLocation);
        if(obj instanceof Animal) {
            Animal animal = (Animal) obj;
            kill(animal); 
        } 
        if(!(obj instanceof Hunter)) {
            setLocation(newLocation);
        } 
        shoot();
    }
    
    private Location shoot()
    { 
        List<Location> adjacent = field.adjacentLocations(location);
        Iterator<Location> it = adjacent.iterator();
        Location animalLoc = null;
        while(it.hasNext()) {
            Location where = it.next();
            Object animal = field.getObjectAt(where);
            if(animal instanceof Animal) {
                Animal thing = (Animal) animal;
                if(thing.isAlive()) { 
                    thing.setDead();
                    animalLoc = where;
                    return where;
                }
            }
        }
        return animalLoc;
    }
    private void kill(Animal animal)
    { 
        animal.setDead();
    }
    protected Location getLocation() 
    { 
        return location; 
    }
    protected void setLocation(Location newLocation)
    {
        if (location != null) {
            field.clear(location);
        }
        location = newLocation;
        field.place(this, newLocation);
    }
    private Location getRandomLocation()
    {
        Location location;
        int x = random.nextInt(field.getWidth());
        int y = random.nextInt(field.getDepth());
        location = new Location(y, x);
        return location;
    }
}
