import java.awt.Color;

/**
 * Write a description of class SimulatorView here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public interface SimulatorView
{
    // instance variables - replace the example below with your own
    void setColor(Class<?> animalClass, Color color);
    boolean isViable(Field field);
    void showStatus(int step, Field field);
    void reset();
    
}
