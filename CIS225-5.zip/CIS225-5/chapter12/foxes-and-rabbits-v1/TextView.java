import java.awt.Color;
import javax.swing.JLabel;

public class TextView implements SimulatorView 
{
    private FieldStats stats;   
    private JLabel stepLabel, population;
    private final String POPULATION_PREFIX = "Population: ";
    public TextView() 
    {
        stats = new FieldStats();
        System.out.println("Textual View of The Fox and Rabbit Simulation");
        population = new JLabel(POPULATION_PREFIX, JLabel.CENTER);
    }
    public boolean isViable(Field field)
    {
        return stats.isViable(field);
    }
    public void reset() 
    {
        stats.reset();
    }
    public void showStatus(int step, Field field) 
    {
        stats.reset();
        System.out.println("Foxes: " + stats.getPopulationDetails(field) + "\tRabbits: " + stats.getPopulationDetails(field));
    }
    public void setColor(Class<?> animalClass, Color color) {}
}